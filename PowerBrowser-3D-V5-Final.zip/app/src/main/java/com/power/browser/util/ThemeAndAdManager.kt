package com.power.browser.util

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.drawable.BitmapDrawable
import android.graphics.drawable.Drawable
import android.net.Uri
import android.util.Base64
import android.webkit.WebView
import androidx.core.content.ContextCompat
import com.power.browser.R
import com.power.browser.model.BookmarkItem
import com.power.browser.model.HistoryItem
import com.power.browser.model.DownloadRecord
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.FileOutputStream

class ThemeAndAdManager(private val context: Context) {

    private val prefs = context.getSharedPreferences("power_browser_prefs", Context.MODE_PRIVATE)

    companion object {
        const val THEME_DIGITAL_DAWN = "digital_dawn"
        const val THEME_COSMIC_DRIFT = "cosmic_drift"
        const val THEME_ROYAL_REFLECTION = "royal_reflection"
        const val THEME_OCEAN_BREEZE = "ocean_breeze"
        const val THEME_CUSTOM = "custom_image"
    }

    val searchEngines = listOf(
        "Google", "DuckDuckGo", "Bing", "Yahoo", "Brave", "Startpage", "Ecosia", "Yandex"
    )

    var isOnboardingDone: Boolean
        get() = prefs.getBoolean("onboarding_done", false)
        set(value) = prefs.edit().putBoolean("onboarding_done", value).apply()

    var selectedTheme: String
        get() = prefs.getString("selected_theme", THEME_ROYAL_REFLECTION) ?: THEME_ROYAL_REFLECTION
        set(value) = prefs.edit().putString("selected_theme", value).apply()

    var dimmerAlpha: Int
        get() = prefs.getInt("dimmer_alpha", 25)
        set(value) = prefs.edit().putInt("dimmer_alpha", value).apply()

    var webPageThemeBgEnabled: Boolean
        get() = prefs.getBoolean("webpage_theme_bg", true)
        set(value) = prefs.edit().putBoolean("webpage_theme_bg", value).apply()

    var adBlockEnabled: Boolean
        get() = prefs.getBoolean("adblock_enabled", true)
        set(value) = prefs.edit().putBoolean("adblock_enabled", value).apply()

    var searchEngine: String
        get() = prefs.getString("search_engine", "Google") ?: "Google"
        set(value) = prefs.edit().putString("search_engine", value).apply()

    fun saveCustomWallpaperFromUri(uri: Uri): Boolean {
        return try {
            val input = context.contentResolver.openInputStream(uri) ?: return false
            val original = BitmapFactory.decodeStream(input)
            input.close()
            if (original == null) return false
            val scaled = Bitmap.createScaledBitmap(original, 480, 854, true)
            val outFile = File(context.filesDir, "custom_theme_bg.jpg")
            FileOutputStream(outFile).use { output ->
                scaled.compress(Bitmap.CompressFormat.JPEG, 75, output)
            }
            selectedTheme = THEME_CUSTOM
            true
        } catch (e: Exception) {
            false
        }
    }

    private fun presetDrawableRes(): Int {
        return when (selectedTheme) {
            THEME_DIGITAL_DAWN -> R.drawable.pb_img_digital_dawn
            THEME_COSMIC_DRIFT -> R.drawable.pb_img_cosmic_drift
            THEME_OCEAN_BREEZE -> R.drawable.pb_img_ocean_breeze
            else -> R.drawable.pb_img_royal_reflection
        }
    }

    fun getActiveBackgroundDrawable(): Drawable? {
        if (selectedTheme == THEME_CUSTOM) {
            val file = File(context.filesDir, "custom_theme_bg.jpg")
            if (file.exists()) {
                val bmp = BitmapFactory.decodeFile(file.absolutePath)
                if (bmp != null) return BitmapDrawable(context.resources, bmp)
            }
        }
        return ContextCompat.getDrawable(context, presetDrawableRes())
    }

    private fun buildWebBackgroundDataUri(): String {
        return try {
            val bmp: Bitmap? = if (selectedTheme == THEME_CUSTOM) {
                val file = File(context.filesDir, "custom_theme_bg.jpg")
                if (file.exists()) BitmapFactory.decodeFile(file.absolutePath) else null
            } else {
                val raw = BitmapFactory.decodeResource(context.resources, presetDrawableRes())
                if (raw != null) Bitmap.createScaledBitmap(raw, 270, 480, true) else null
            }
            if (bmp != null) {
                val baos = ByteArrayOutputStream()
                bmp.compress(Bitmap.CompressFormat.JPEG, 68, baos)
                val b64 = Base64.encodeToString(baos.toByteArray(), Base64.NO_WRAP)
                "data:image/jpeg;base64,$b64"
            } else {
                ""
            }
        } catch (e: Exception) {
            ""
        }
    }

    fun getSearchUrl(query: String): String {
        val trimmed = query.trim()
        if (trimmed.startsWith("http://") || trimmed.startsWith("https://")) return trimmed
        if (trimmed.contains(".") && !trimmed.contains(" ")) return "https://$trimmed"
        val encoded = Uri.encode(trimmed)
        return when (searchEngine) {
            "DuckDuckGo" -> "https://duckduckgo.com/?q=$encoded"
            "Bing" -> "https://www.bing.com/search?q=$encoded"
            "Yahoo" -> "https://search.yahoo.com/search?p=$encoded"
            "Brave" -> "https://search.brave.com/search?q=$encoded"
            "Startpage" -> "https://www.startpage.com/sp/search?query=$encoded"
            "Ecosia" -> "https://www.ecosia.org/search?q=$encoded"
            "Yandex" -> "https://yandex.com/search/?text=$encoded"
            else -> "https://www.google.com/search?q=$encoded"
        }
    }

    private val blockedHosts = listOf(
        "doubleclick.net", "googlesyndication.com", "googleadservices.com",
        "adnxs.com", "adsrvr.org", "taboola.com", "outbrain.com",
        "cpro.baidu.com", "pos.baidu.com", "popads.net", "propellerads.com",
        "adcolony.com", "unityads.unity3d.com", "applovin.com", "inmobi.com"
    )

    fun isAdUrl(url: String): Boolean {
        if (!adBlockEnabled) return false
        val lower = url.lowercase()
        return blockedHosts.any { lower.contains(it) }
    }

    fun injectScripts(webView: WebView) {
        if (adBlockEnabled) {
            val adJs = "(function(){var s=['[id*=\"ad_\"]','[id*=\"ads\"]','[class*=\"ad-banner\"]','[class*=\"sponsored\"]','ins.adsbygoogle'];s.forEach(function(q){document.querySelectorAll(q).forEach(function(e){e.remove();});});})();"
            webView.evaluateJavascript(adJs, null)
        }

        if (webPageThemeBgEnabled) {
            val uri = buildWebBackgroundDataUri()
            val css = if (uri.isNotEmpty()) {
                "html,body{background-color:transparent !important;background-image:linear-gradient(rgba(12,8,26,0.42),rgba(12,8,26,0.52)),url('" + uri + "') !important;background-size:cover !important;background-position:center center !important;background-attachment:fixed !important;color:#FFFFFF !important;}div,section,article,header,nav,main,footer,ul,li,table,tr,td{background-color:rgba(18,13,36,0.56) !important;color:#F6F3FF !important;border-color:rgba(255,255,255,0.14) !important;}a{color:#72EFDD !important;}input,textarea,select{background-color:rgba(28,20,56,0.85) !important;color:#FFFFFF !important;}"
            } else {
                "html,body{background:rgba(20,12,42,0.75) !important;color:#FFFFFF !important;}"
            }
            val js = "(function(){var o=document.getElementById('power-glass-theme');if(o)o.remove();var st=document.createElement('style');st.id='power-glass-theme';st.textContent=" + JSONObject.quote(css) + ";document.head.appendChild(st);})();"
            webView.evaluateJavascript(js, null)
        } else {
            webView.evaluateJavascript("(function(){var o=document.getElementById('power-glass-theme');if(o)o.remove();})();", null)
        }
    }

    fun getBookmarks(): MutableList<BookmarkItem> {
        val raw = prefs.getString("bookmarks_json", "[]") ?: "[]"
        val arr = JSONArray(raw)
        val list = mutableListOf<BookmarkItem>()
        for (i in 0 until arr.length()) {
            val obj = arr.getJSONObject(i)
            list.add(BookmarkItem(obj.getString("title"), obj.getString("url")))
        }
        return list
    }

    fun addBookmark(title: String, url: String) {
        val list = getBookmarks()
        if (list.none { it.url == url }) {
            list.add(0, BookmarkItem(title.ifBlank { url }, url))
            saveBookmarks(list)
        }
    }

    private fun saveBookmarks(list: List<BookmarkItem>) {
        val arr = JSONArray()
        list.forEach {
            arr.put(JSONObject().put("title", it.title).put("url", it.url))
        }
        prefs.edit().putString("bookmarks_json", arr.toString()).apply()
    }

    fun getHistory(): MutableList<HistoryItem> {
        val raw = prefs.getString("history_json", "[]") ?: "[]"
        val arr = JSONArray(raw)
        val list = mutableListOf<HistoryItem>()
        for (i in 0 until arr.length()) {
            val obj = arr.getJSONObject(i)
            list.add(HistoryItem(obj.getString("title"), obj.getString("url"), obj.optLong("ts", 0L)))
        }
        return list
    }

    fun addHistory(title: String, url: String) {
        if (url.startsWith("power://")) return
        val list = getHistory()
        list.add(0, HistoryItem(title.ifBlank { url }, url))
        val trimmed = list.take(100)
        val arr = JSONArray()
        trimmed.forEach {
            arr.put(JSONObject().put("title", it.title).put("url", it.url).put("ts", it.timestamp))
        }
        prefs.edit().putString("history_json", arr.toString()).apply()
    }


    fun getDownloads(): MutableList<DownloadRecord> {
        val raw = prefs.getString("downloads_json", "[]") ?: "[]"
        val arr = JSONArray(raw)
        val list = mutableListOf<DownloadRecord>()
        for (i in 0 until arr.length()) {
            val obj = arr.getJSONObject(i)
            list.add(
                DownloadRecord(
                    obj.getString("fileName"),
                    obj.getString("url"),
                    obj.optLong("ts", 0L)
                )
            )
        }
        return list
    }

    fun addDownloadRecord(fileName: String, url: String) {
        val list = getDownloads()
        list.add(0, DownloadRecord(fileName, url))
        val trimmed = list.take(50)
        val arr = JSONArray()
        trimmed.forEach {
            arr.put(
                JSONObject()
                    .put("fileName", it.fileName)
                    .put("url", it.url)
                    .put("ts", it.timestamp)
            )
        }
        prefs.edit().putString("downloads_json", arr.toString()).apply()
    }

    fun clearAllBrowsingData() {
        prefs.edit().remove("history_json").apply()
    }
}
