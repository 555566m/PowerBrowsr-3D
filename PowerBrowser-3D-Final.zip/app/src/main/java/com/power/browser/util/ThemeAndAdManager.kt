package com.power.browser.util

import android.content.Context
import android.graphics.BitmapFactory
import android.graphics.drawable.BitmapDrawable
import android.graphics.drawable.Drawable
import android.net.Uri
import android.webkit.WebView
import androidx.core.content.ContextCompat
import com.power.browser.R
import com.power.browser.model.BookmarkItem
import com.power.browser.model.HistoryItem
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream

class ThemeAndAdManager(private val context: Context) {

    private val prefs = context.getSharedPreferences("power_browser_prefs", Context.MODE_PRIVATE)

    companion object {
        const val THEME_DIGITAL_DAWN = "digital_dawn"
        const val THEME_COSMIC_DRIFT = "cosmic_drift"
        const val THEME_ROYAL_REFLECTION = "royal_reflection"
        const val THEME_OCEAN_BREEZE = "ocean_breeze"
        const val THEME_CUSTOM = "custom_image"
    }

    var isOnboardingDone: Boolean
        get() = prefs.getBoolean("onboarding_done", false)
        set(value) = prefs.edit().putBoolean("onboarding_done", value).apply()

    var selectedTheme: String
        get() = prefs.getString("selected_theme", THEME_ROYAL_REFLECTION) ?: THEME_ROYAL_REFLECTION
        set(value) = prefs.edit().putString("selected_theme", value).apply()

    var dimmerAlpha: Int
        get() = prefs.getInt("dimmer_alpha", 35)
        set(value) = prefs.edit().putInt("dimmer_alpha", value).apply()

    var webPageThemeBgEnabled: Boolean
        get() = prefs.getBoolean("webpage_theme_bg", true)
        set(value) = prefs.edit().putBoolean("webpage_theme_bg", value).apply()

    var adBlockEnabled: Boolean
        get() = prefs.getBoolean("adblock_enabled", true)
        set(value) = prefs.edit().putBoolean("adblock_enabled", value).apply()

    var searchEngine: String
        get() = prefs.getString("search_engine", "Google") ?: "Google"
        set(value) = prefs.edit().putString("search_engine", value).apply()

    fun saveCustomWallpaperFromUri(uri: Uri): Boolean {
        return try {
            val input = context.contentResolver.openInputStream(uri) ?: return false
            val outFile = File(context.filesDir, "custom_theme_bg.jpg")
            FileOutputStream(outFile).use { output ->
                input.copyTo(output)
            }
            input.close()
            selectedTheme = THEME_CUSTOM
            true
        } catch (e: Exception) {
            false
        }
    }

    fun getActiveBackgroundDrawable(): Drawable? {
        if (selectedTheme == THEME_CUSTOM) {
            val file = File(context.filesDir, "custom_theme_bg.jpg")
            if (file.exists()) {
                val bmp = BitmapFactory.decodeFile(file.absolutePath)
                if (bmp != null) return BitmapDrawable(context.resources, bmp)
            }
        }
        val resId = when (selectedTheme) {
            THEME_DIGITAL_DAWN -> R.drawable.pb_wp_digital_dawn
            THEME_COSMIC_DRIFT -> R.drawable.pb_wp_cosmic_drift
            THEME_OCEAN_BREEZE -> R.drawable.pb_wp_ocean_breeze
            else -> R.drawable.pb_wp_royal_reflection
        }
        return ContextCompat.getDrawable(context, resId)
    }

    fun getSearchUrl(query: String): String {
        val trimmed = query.trim()
        if (trimmed.startsWith("http://") || trimmed.startsWith("https://")) return trimmed
        if (trimmed.contains(".") && !trimmed.contains(" ")) return "https://$trimmed"
        val encoded = Uri.encode(trimmed)
        return when (searchEngine) {
            "DuckDuckGo" -> "https://duckduckgo.com/?q=$encoded"
            "Bing" -> "https://www.bing.com/search?q=$encoded"
            "Yahoo" -> "https://search.yahoo.com/search?p=$encoded"
            else -> "https://www.google.com/search?q=$encoded"
        }
    }

    private val blockedHosts = listOf(
        "doubleclick.net", "googlesyndication.com", "googleadservices.com",
        "adnxs.com", "adsrvr.org", "taboola.com", "outbrain.com",
        "cpro.baidu.com", "pos.baidu.com", "popads.net", "propellerads.com",
        "adcolony.com", "unityads.unity3d.com", "applovin.com", "inmobi.com"
    )

    fun isAdUrl(url: String): Boolean {
        if (!adBlockEnabled) return false
        val lower = url.lowercase()
        return blockedHosts.any { lower.contains(it) }
    }

    fun injectScripts(webView: WebView) {
        if (adBlockEnabled) {
            val adJs = """
                (function(){
                    var selectors = ['[id*="ad_"]','[id*="ads"]','[class*="ad-banner"]','[class*="sponsored"]','ins.adsbygoogle','iframe[src*="doubleclick"]'];
                    selectors.forEach(function(sel){
                        document.querySelectorAll(sel).forEach(function(el){ el.remove(); });
                    });
                })();
            """.trimIndent()
            webView.evaluateJavascript(adJs, null)
        }

        if (webPageThemeBgEnabled) {
            val themeCssJs = """
                (function(){
                    if(document.getElementById('power-glass-theme')) return;
                    var style = document.createElement('style');
                    style.id = 'power-glass-theme';
                    style.innerHTML = `
                        html, body {
                            background: rgba(13, 10, 26, 0.72) !important;
                            color: #F4F1FF !important;
                        }
                        div, section, article, header, nav, main, footer, ul, li, table, tr, td {
                            background-color: rgba(22, 17, 43, 0.45) !important;
                            color: #F4F1FF !important;
                            border-color: rgba(255,255,255,0.12) !important;
                        }
                        a { color: #72EFDD !important; }
                        input, textarea, select {
                            background: rgba(35, 27, 68, 0.85) !important;
                            color: #FFFFFF !important;
                        }
                    `;
                    document.head.appendChild(style);
                })();
            """.trimIndent()
            webView.evaluateJavascript(themeCssJs, null)
        }
    }

    fun getBookmarks(): MutableList<BookmarkItem> {
        val raw = prefs.getString("bookmarks_json", "[]") ?: "[]"
        val arr = JSONArray(raw)
        val list = mutableListOf<BookmarkItem>()
        for (i in 0 until arr.length()) {
            val obj = arr.getJSONObject(i)
            list.add(BookmarkItem(obj.getString("title"), obj.getString("url")))
        }
        return list
    }

    fun addBookmark(title: String, url: String) {
        val list = getBookmarks()
        if (list.none { it.url == url }) {
            list.add(0, BookmarkItem(title.ifBlank { url }, url))
            saveBookmarks(list)
        }
    }

    private fun saveBookmarks(list: List<BookmarkItem>) {
        val arr = JSONArray()
        list.forEach {
            arr.put(JSONObject().put("title", it.title).put("url", it.url))
        }
        prefs.edit().putString("bookmarks_json", arr.toString()).apply()
    }

    fun getHistory(): MutableList<HistoryItem> {
        val raw = prefs.getString("history_json", "[]") ?: "[]"
        val arr = JSONArray(raw)
        val list = mutableListOf<HistoryItem>()
        for (i in 0 until arr.length()) {
            val obj = arr.getJSONObject(i)
            list.add(HistoryItem(obj.getString("title"), obj.getString("url"), obj.optLong("ts", 0L)))
        }
        return list
    }

    fun addHistory(title: String, url: String) {
        if (url.startsWith("power://")) return
        val list = getHistory()
        list.add(0, HistoryItem(title.ifBlank { url }, url))
        val trimmed = list.take(100)
        val arr = JSONArray()
        trimmed.forEach {
            arr.put(JSONObject().put("title", it.title).put("url", it.url).put("ts", it.timestamp))
        }
        prefs.edit().putString("history_json", arr.toString()).apply()
    }

    fun clearAllBrowsingData() {
        prefs.edit().remove("history_json").apply()
    }
}
