package com.power.browser.ui

import android.animation.ObjectAnimator
import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.power.browser.databinding.ActivityOnboardingBinding
import com.power.browser.util.ThemeAndAdManager

class OnboardingActivity : AppCompatActivity() {

    private lateinit var binding: ActivityOnboardingBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityOnboardingBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.ivWelcomeLogo.cameraDistance = 8000f * resources.displayMetrics.density
        ObjectAnimator.ofFloat(binding.ivWelcomeLogo, "rotationY", -18f, 18f).apply {
            duration = 2000
            repeatCount = ObjectAnimator.INFINITE
            repeatMode = ObjectAnimator.REVERSE
            start()
        }

        binding.btnBringItOn.setOnClickListener {
            ThemeAndAdManager(this).isOnboardingDone = true
            startActivity(Intent(this, MainActivity::class.java))
            overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)
            finish()
        }
    }
}
