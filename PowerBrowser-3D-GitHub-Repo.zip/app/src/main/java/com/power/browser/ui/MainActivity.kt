package com.power.browser.ui

import android.animation.ObjectAnimator
import android.annotation.SuppressLint
import android.app.DownloadManager
import android.content.Context
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.webkit.*
import android.widget.*
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.bottomsheet.BottomSheetDialog
import com.power.browser.R
import com.power.browser.databinding.*
import com.power.browser.model.BrowserTab
import com.power.browser.model.SpeedDialItem
import com.power.browser.util.ThemeAndAdManager
import java.io.ByteArrayInputStream

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private lateinit var manager: ThemeAndAdManager

    private val tabs = mutableListOf<BrowserTab>()
    private var activeTabIndex = 0
    private var blockedAdsCount = 0
    private var isIncognito = false
    private var isDesktopMode = false

    private val pickCustomWallpaper =
        registerForActivityResult(ActivityResultContracts.GetContent()) { uri: Uri? ->
            if (uri != null && manager.saveCustomWallpaperFromUri(uri)) {
                applyActiveTheme()
                Toast.makeText(this, "Custom background applied!", Toast.LENGTH_SHORT).show()
            }
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        manager = ThemeAndAdManager(this)

        setup3DHomeAnimation()
        setupSpeedDial()
        applyActiveTheme()
        createNewTab(switchToTab = true)
        setupControls()
        setupBackNavigation()

        intent?.dataString?.let { incomingUrl ->
            if (incomingUrl.startsWith("http")) loadUrlInActiveTab(incomingUrl)
        }
    }

    private fun setup3DHomeAnimation() {
        binding.ivHomeLogo3D.cameraDistance = 8000f * resources.displayMetrics.density
        ObjectAnimator.ofFloat(binding.ivHomeLogo3D, "rotationY", -16f, 16f).apply {
            duration = 2400
            repeatCount = ObjectAnimator.INFINITE
            repeatMode = ObjectAnimator.REVERSE
            start()
        }
    }

    private fun applyActiveTheme() {
        binding.ivThemeBackground.setImageDrawable(manager.getActiveBackgroundDrawable())
        val alphaInt = ((manager.dimmerAlpha / 100f) * 230).toInt().coerceIn(0, 230)
        binding.viewThemeDimmer.setBackgroundColor(Color.argb(alphaInt, 10, 7, 24))
        binding.tvSearchEngineBadge.text = manager.searchEngine

        tabs.forEach { tab ->
            tab.webView.setBackgroundColor(
                if (manager.webPageThemeBgEnabled) Color.TRANSPARENT else Color.WHITE
            )
            if (!tab.isHome) manager.injectScripts(tab.webView)
        }
    }

    private fun setupSpeedDial() {
        val sites = listOf(
            SpeedDialItem("Google", "https://www.google.com", "G", Color.parseColor("#4285F4")),
            SpeedDialItem("YouTube", "https://m.youtube.com", "▶", Color.parseColor("#FF0000")),
            SpeedDialItem("Wikipedia", "https://www.wikipedia.org", "W", Color.parseColor("#3366CC")),
            SpeedDialItem("GitHub", "https://github.com", "GH", Color.parseColor("#6E40C9")),
            SpeedDialItem("DuckDuckGo", "https://duckduckgo.com", "D", Color.parseColor("#DE5833")),
            SpeedDialItem("BBC News", "https://www.bbc.com", "B", Color.parseColor("#BB1919")),
            SpeedDialItem("Amazon", "https://www.amazon.in", "A", Color.parseColor("#FF9900")),
            SpeedDialItem("Instagram", "https://www.instagram.com", "IG", Color.parseColor("#E1306C"))
        )

        binding.rvSpeedDial.layoutManager = GridLayoutManager(this, 4)
        binding.rvSpeedDial.adapter = object : RecyclerView.Adapter<SpeedDialVH>() {
            override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): SpeedDialVH {
                val v = LayoutInflater.from(parent.context)
                    .inflate(R.layout.item_speed_dial, parent, false)
                return SpeedDialVH(v)
            }

            override fun getItemCount() = sites.size

            override fun onBindViewHolder(holder: SpeedDialVH, position: Int) {
                val item = sites[position]
                holder.tvTitle.text = item.title
                holder.tvInitial.text = item.initial
                holder.tvInitial.setTextColor(item.badgeColor)
                holder.itemView.setOnClickListener { loadUrlInActiveTab(item.url) }
            }
        }
    }

    class SpeedDialVH(v: View) : RecyclerView.ViewHolder(v) {
        val tvInitial: TextView = v.findViewById(R.id.tvSiteInitial)
        val tvTitle: TextView = v.findViewById(R.id.tvSiteTitle)
    }

    @SuppressLint("SetJavaScriptEnabled")
    private fun createWebViewInstance(): WebView {
        return WebView(this).apply {
            setBackgroundColor(if (manager.webPageThemeBgEnabled) Color.TRANSPARENT else Color.WHITE)
            settings.apply {
                javaScriptEnabled = true
                domStorageEnabled = !isIncognito
                databaseEnabled = !isIncognito
                useWideViewPort = true
                loadWithOverviewMode = true
                builtInZoomControls = true
                displayZoomControls = false
                allowFileAccess = true
                mixedContentMode = WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE
                if (isDesktopMode) {
                    userAgentString =
                        "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36"
                }
            }

            webViewClient = object : WebViewClient() {
                override fun shouldInterceptRequest(
                    view: WebView?,
                    request: WebResourceRequest?
                ): WebResourceResponse? {
                    val reqUrl = request?.url?.toString() ?: return null
                    if (manager.isAdUrl(reqUrl)) {
                        runOnUiThread {
                            blockedAdsCount++
                            binding.tvBlockedCount.text = blockedAdsCount.toString()
                        }
                        return WebResourceResponse("text/plain", "UTF-8", ByteArrayInputStream(ByteArray(0)))
                    }
                    return super.shouldInterceptRequest(view, request)
                }

                override fun onPageFinished(view: WebView?, url: String?) {
                    super.onPageFinished(view, url)
                    binding.webProgressBar.visibility = View.GONE
                    val safeUrl = url ?: return
                    val current = tabs.getOrNull(activeTabIndex)
                    if (current != null && current.webView == view) {
                        current.url = safeUrl
                        current.title = view?.title ?: safeUrl
                        binding.etUrlBar.setText(safeUrl)
                    }
                    if (!isIncognito) {
                        manager.addHistory(view?.title ?: safeUrl, safeUrl)
                    }
                    view?.let { manager.injectScripts(it) }
                }
            }

            webChromeClient = object : WebChromeClient() {
                override fun onProgressChanged(view: WebView?, newProgress: Int) {
                    if (newProgress in 1..99) {
                        binding.webProgressBar.visibility = View.VISIBLE
                        binding.webProgressBar.progress = newProgress
                    } else {
                        binding.webProgressBar.visibility = View.GONE
                    }
                }
            }

            setDownloadListener { url, userAgent, contentDisposition, mimeType, _ ->
                try {
                    val fileName = URLUtil.guessFileName(url, contentDisposition, mimeType)
                    val request = DownloadManager.Request(Uri.parse(url)).apply {
                        setMimeType(mimeType)
                        addRequestHeader("User-Agent", userAgent)
                        setTitle(fileName)
                        setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
                        setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, fileName)
                    }
                    val dm = getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager
                    dm.enqueue(request)
                    Toast.makeText(this@MainActivity, "Downloading $fileName...", Toast.LENGTH_SHORT).show()
                } catch (e: Exception) {
                    Toast.makeText(this@MainActivity, "Download failed", Toast.LENGTH_SHORT).show()
                }
            }
        }
    }

    private fun createNewTab(switchToTab: Boolean) {
        val tab = BrowserTab(webView = createWebViewInstance())
        tabs.add(tab)
        if (switchToTab) switchToTab(tabs.lastIndex)
        binding.tvTabCount.text = tabs.size.toString()
    }

    private fun switchToTab(index: Int) {
        if (index !in tabs.indices) return
        activeTabIndex = index
        val tab = tabs[index]
        binding.webViewContainer.removeAllViews()
        binding.webViewContainer.addView(
            tab.webView,
            FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
            )
        )
        if (tab.isHome) {
            binding.homePageContainer.visibility = View.VISIBLE
            binding.webViewContainer.visibility = View.GONE
            binding.etUrlBar.setText("")
        } else {
            binding.homePageContainer.visibility = View.GONE
            binding.webViewContainer.visibility = View.VISIBLE
            binding.etUrlBar.setText(tab.url)
        }
        binding.tvTabCount.text = tabs.size.toString()
    }

    private fun loadUrlInActiveTab(rawInput: String) {
        val targetUrl = manager.getSearchUrl(rawInput)
        val tab = tabs.getOrNull(activeTabIndex) ?: return
        tab.isHome = false
        tab.url = targetUrl
        binding.homePageContainer.visibility = View.GONE
        binding.webViewContainer.visibility = View.VISIBLE
        binding.etUrlBar.setText(targetUrl)
        tab.webView.loadUrl(targetUrl)
        hideKeyboard()
    }

    private fun setupControls() {
        binding.etUrlBar.setOnEditorActionListener { _, actionId, _ ->
            if (actionId == EditorInfo.IME_ACTION_GO || actionId == EditorInfo.IME_ACTION_SEARCH) {
                val query = binding.etUrlBar.text.toString()
                if (query.isNotBlank()) loadUrlInActiveTab(query)
                true
            } else false
        }

        binding.tvHomeSearchTrigger.setOnClickListener {
            binding.etUrlBar.requestFocus()
            val imm = getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
            imm.showSoftInput(binding.etUrlBar, InputMethodManager.SHOW_IMPLICIT)
        }

        binding.btnRefreshStop.setOnClickListener {
            val tab = tabs.getOrNull(activeTabIndex) ?: return@setOnClickListener
            if (!tab.isHome) tab.webView.reload()
        }

        binding.btnThemeSetup.setOnClickListener { showThemeSetupDialog() }
        binding.btnCustomizeWallpaperPill.setOnClickListener { showThemeSetupDialog() }

        binding.btnBack.setOnClickListener { handleBackAction() }
        binding.btnForward.setOnClickListener {
            val tab = tabs.getOrNull(activeTabIndex) ?: return@setOnClickListener
            if (!tab.isHome && tab.webView.canGoForward()) tab.webView.goForward()
        }
        binding.btnHome.setOnClickListener {
            val tab = tabs.getOrNull(activeTabIndex) ?: return@setOnClickListener
            tab.isHome = true
            tab.title = "Home"
            switchToTab(activeTabIndex)
        }
        binding.btnTabs.setOnClickListener { showTabsDialog() }
        binding.btnMenu.setOnClickListener { showBrowserMenu() }
    }

    private fun showThemeSetupDialog() {
        val dialog = BottomSheetDialog(this)
        val sheet = DialogThemeSetupBinding.inflate(layoutInflater)
        dialog.setContentView(sheet.root)

        fun updateCheckmarks(selected: String) {
            sheet.checkDigitalDawn.visibility =
                if (selected == ThemeAndAdManager.THEME_DIGITAL_DAWN) View.VISIBLE else View.GONE
            sheet.checkCosmicDrift.visibility =
                if (selected == ThemeAndAdManager.THEME_COSMIC_DRIFT) View.VISIBLE else View.GONE
            sheet.checkRoyalReflection.visibility =
                if (selected == ThemeAndAdManager.THEME_ROYAL_REFLECTION) View.VISIBLE else View.GONE
            sheet.checkOceanBreeze.visibility =
                if (selected == ThemeAndAdManager.THEME_OCEAN_BREEZE) View.VISIBLE else View.GONE
        }

        updateCheckmarks(manager.selectedTheme)
        sheet.seekDimmer.progress = manager.dimmerAlpha
        sheet.switchWebPageThemeBg.isChecked = manager.webPageThemeBgEnabled

        sheet.cardDigitalDawn.setOnClickListener {
            manager.selectedTheme = ThemeAndAdManager.THEME_DIGITAL_DAWN
            updateCheckmarks(manager.selectedTheme)
            applyActiveTheme()
        }
        sheet.cardCosmicDrift.setOnClickListener {
            manager.selectedTheme = ThemeAndAdManager.THEME_COSMIC_DRIFT
            updateCheckmarks(manager.selectedTheme)
            applyActiveTheme()
        }
        sheet.cardRoyalReflection.setOnClickListener {
            manager.selectedTheme = ThemeAndAdManager.THEME_ROYAL_REFLECTION
            updateCheckmarks(manager.selectedTheme)
            applyActiveTheme()
        }
        sheet.cardOceanBreeze.setOnClickListener {
            manager.selectedTheme = ThemeAndAdManager.THEME_OCEAN_BREEZE
            updateCheckmarks(manager.selectedTheme)
            applyActiveTheme()
        }

        sheet.btnUploadCustomImage.setOnClickListener {
            dialog.dismiss()
            pickCustomWallpaper.launch("image/*")
        }

        sheet.seekDimmer.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar?, progress: Int, fromUser: Boolean) {
                manager.dimmerAlpha = progress
                applyActiveTheme()
            }
            override fun onStartTrackingTouch(sb: SeekBar?) {}
            override fun onStopTrackingTouch(sb: SeekBar?) {}
        })

        sheet.switchWebPageThemeBg.setOnCheckedChangeListener { _, isChecked ->
            manager.webPageThemeBgEnabled = isChecked
            applyActiveTheme()
        }

        sheet.btnConfirmTheme.setOnClickListener {
            applyActiveTheme()
            dialog.dismiss()
        }

        dialog.show()
    }

    private fun showTabsDialog() {
        val dialog = BottomSheetDialog(this)
        val sheet = DialogTabsBinding.inflate(layoutInflater)
        dialog.setContentView(sheet.root)

        val titles = tabs.mapIndexed { idx, t -> "${idx + 1}. ${t.title} (${t.url})" }
        sheet.lvTabs.adapter = ArrayAdapter(this, android.R.layout.simple_list_item_1, titles)

        sheet.lvTabs.setOnItemClickListener { _, _, position, _ ->
            switchToTab(position)
            dialog.dismiss()
        }

        sheet.lvTabs.setOnItemLongClickListener { _, _, position, _ ->
            if (tabs.size > 1) {
                tabs[position].webView.destroy()
                tabs.removeAt(position)
                switchToTab(0)
                dialog.dismiss()
            }
            true
        }

        sheet.btnNewTab.setOnClickListener {
            createNewTab(switchToTab = true)
            dialog.dismiss()
        }

        dialog.show()
    }

    private fun showBrowserMenu() {
        val dialog = BottomSheetDialog(this)
        val sheet = DialogBrowserMenuBinding.inflate(layoutInflater)
        dialog.setContentView(sheet.root)

        sheet.menuAdBlockToggle.text = if (manager.adBlockEnabled) "AdBlock: ON" else "AdBlock: OFF"
        sheet.menuIncognito.text = if (isIncognito) "Incognito: ON" else "Incognito"
        sheet.menuDesktopMode.text = if (isDesktopMode) "Desktop: ON" else "Desktop UI"

        sheet.menuAddBookmark.setOnClickListener {
            val tab = tabs.getOrNull(activeTabIndex)
            if (tab != null && !tab.isHome) {
                manager.addBookmark(tab.title, tab.url)
                Toast.makeText(this, "Bookmarked!", Toast.LENGTH_SHORT).show()
            }
            dialog.dismiss()
        }

        sheet.menuBookmarksList.setOnClickListener {
            dialog.dismiss()
            val bookmarks = manager.getBookmarks()
            val items = bookmarks.map { "${it.title}
${it.url}" }.toTypedArray()
            AlertDialog.Builder(this)
                .setTitle("Saved Bookmarks")
                .setItems(items) { _, which -> loadUrlInActiveTab(bookmarks[which].url) }
                .show()
        }

        sheet.menuHistory.setOnClickListener {
            dialog.dismiss()
            val history = manager.getHistory()
            val items = history.map { "${it.title}
${it.url}" }.toTypedArray()
            AlertDialog.Builder(this)
                .setTitle("Browsing History")
                .setItems(items) { _, which -> loadUrlInActiveTab(history[which].url) }
                .show()
        }

        sheet.menuIncognito.setOnClickListener {
            isIncognito = !isIncognito
            binding.tvIncognitoBadge.visibility = if (isIncognito) View.VISIBLE else View.GONE
            Toast.makeText(this, if (isIncognito) "Incognito Enabled" else "Normal Mode", Toast.LENGTH_SHORT).show()
            dialog.dismiss()
        }

        sheet.menuDesktopMode.setOnClickListener {
            isDesktopMode = !isDesktopMode
            val tab = tabs.getOrNull(activeTabIndex)
            tab?.webView?.settings?.userAgentString = if (isDesktopMode) {
                "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36"
            } else null
            tab?.webView?.reload()
            dialog.dismiss()
        }

        sheet.menuSearchEngine.setOnClickListener {
            dialog.dismiss()
            val engines = arrayOf("Google", "DuckDuckGo", "Bing", "Yahoo")
            AlertDialog.Builder(this)
                .setTitle("Select Search Engine")
                .setItems(engines) { _, which ->
                    manager.searchEngine = engines[which]
                    applyActiveTheme()
                }
                .show()
        }

        sheet.menuAdBlockToggle.setOnClickListener {
            manager.adBlockEnabled = !manager.adBlockEnabled
            Toast.makeText(this, "AdBlock: ${manager.adBlockEnabled}", Toast.LENGTH_SHORT).show()
            dialog.dismiss()
        }

        sheet.menuThemes.setOnClickListener {
            dialog.dismiss()
            showThemeSetupDialog()
        }

        sheet.menuClearData.setOnClickListener {
            manager.clearAllBrowsingData()
            WebStorage.getInstance().deleteAllData()
            CookieManager.getInstance().removeAllCookies(null)
            Toast.makeText(this, "History, Cache & Cookies Cleared", Toast.LENGTH_SHORT).show()
            dialog.dismiss()
        }

        dialog.show()
    }

    private fun handleBackAction() {
        val tab = tabs.getOrNull(activeTabIndex) ?: return
        if (!tab.isHome && tab.webView.canGoBack()) {
            tab.webView.goBack()
        } else if (!tab.isHome) {
            tab.isHome = true
            switchToTab(activeTabIndex)
        } else {
            finish()
        }
    }

    private fun setupBackNavigation() {
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() = handleBackAction()
        })
    }

    private fun hideKeyboard() {
        val imm = getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
        imm.hideSoftInputFromWindow(binding.etUrlBar.windowToken, 0)
    }
}
