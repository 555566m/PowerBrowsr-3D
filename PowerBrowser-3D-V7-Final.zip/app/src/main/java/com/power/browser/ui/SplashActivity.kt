package com.power.browser.ui

import android.animation.ObjectAnimator
import android.animation.PropertyValuesHolder
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.animation.OvershootInterpolator
import androidx.appcompat.app.AppCompatActivity
import com.power.browser.databinding.PbActivitySplashBinding
import com.power.browser.util.ThemeAndAdManager

class SplashActivity : AppCompatActivity() {

    private lateinit var binding: PbActivitySplashBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = PbActivitySplashBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val scale = resources.displayMetrics.density
        binding.ivLogo3D.cameraDistance = 8000f * scale
        binding.logoContainer.cameraDistance = 8000f * scale

        binding.logoContainer.scaleX = 0.5f
        binding.logoContainer.scaleY = 0.5f
        binding.logoContainer.alpha = 0f

        binding.logoContainer.animate()
            .scaleX(1f)
            .scaleY(1f)
            .alpha(1f)
            .setDuration(750)
            .setInterpolator(OvershootInterpolator(1.5f))
            .start()

        val spin3D = ObjectAnimator.ofPropertyValuesHolder(
            binding.ivLogo3D,
            PropertyValuesHolder.ofFloat("rotationY", -22f, 22f),
            PropertyValuesHolder.ofFloat("translationY", -10f, 10f)
        ).apply {
            duration = 1400
            repeatCount = ObjectAnimator.INFINITE
            repeatMode = ObjectAnimator.REVERSE
            start()
        }

        Handler(Looper.getMainLooper()).postDelayed({
            spin3D.cancel()
            val manager = ThemeAndAdManager(this)
            val nextIntent = if (manager.isOnboardingDone) {
                Intent(this, MainActivity::class.java)
            } else {
                Intent(this, OnboardingActivity::class.java)
            }
            startActivity(nextIntent)
            overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)
            finish()
        }, 1900)
    }
}
