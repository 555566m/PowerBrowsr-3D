package com.power.browser.util

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Shader
import android.graphics.drawable.BitmapDrawable
import android.graphics.drawable.Drawable
import android.net.Uri
import android.util.Base64
import android.webkit.WebView
import androidx.core.content.ContextCompat
import com.power.browser.R
import com.power.browser.model.BookmarkEntry
import com.power.browser.model.DownloadEntry
import com.power.browser.model.HistoryEntry
import com.power.browser.model.QuickSiteItem
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.FileOutputStream

class BrowserManager(private val context: Context) {

    private val prefs = context.getSharedPreferences("pb_a17_prefs", Context.MODE_PRIVATE)

    companion object {
        const val THEME_ROSE = "rose_quartz"
        const val THEME_SUNSET = "royal_sunset"
        const val THEME_MINT = "cosmic_mint"
        const val THEME_OCEAN = "ocean_wave"
        const val THEME_CUSTOM = "custom_wallpaper"
    }

    val searchEngines = listOf(
        "Google", "DuckDuckGo", "Bing", "Yahoo", "Brave", "Startpage", "Ecosia", "Yandex"
    )

    var activeTheme: String
        get() = prefs.getString("active_theme", THEME_ROSE) ?: THEME_ROSE
        set(value) = prefs.edit().putString("active_theme", value).apply()

    var webWallpaperEnabled: Boolean
        get() = prefs.getBoolean("web_wallpaper_enabled", true)
        set(value) = prefs.edit().putBoolean("web_wallpaper_enabled", value).apply()

    var darkModeEnabled: Boolean
        get() = prefs.getBoolean("dark_mode_enabled", false)
        set(value) = prefs.edit().putBoolean("dark_mode_enabled", value).apply()

    var adBlockEnabled: Boolean
        get() = prefs.getBoolean("adblock_enabled", true)
        set(value) = prefs.edit().putBoolean("adblock_enabled", value).apply()

    var blockImagesEnabled: Boolean
        get() = prefs.getBoolean("block_images_enabled", false)
        set(value) = prefs.edit().putBoolean("block_images_enabled", value).apply()

    var searchEngine: String
        get() = prefs.getString("search_engine", "Google") ?: "Google"
        set(value) = prefs.edit().putString("search_engine", value).apply()

    var memoText: String
        get() = prefs.getString("memo_text", "") ?: ""
        set(value) = prefs.edit().putString("memo_text", value).apply()

    fun defaultQuickSites(): MutableList<QuickSiteItem> {
        val raw = prefs.getString("quick_sites_json", null)
        if (raw != null) {
            val arr = JSONArray(raw)
            val out = mutableListOf<QuickSiteItem>()
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                out.add(QuickSiteItem(o.getString("title"), o.getString("url"), o.getString("glyph"), o.getString("color")))
            }
            if (out.isNotEmpty()) return out
        }
        return mutableListOf(
            QuickSiteItem("Google", "https://www.google.com", "G", "#4285F4"),
            QuickSiteItem("YouTube", "https://m.youtube.com", "▶", "#FF0000"),
            QuickSiteItem("Facebook", "https://m.facebook.com", "f", "#1877F2"),
            QuickSiteItem("Instagram", "https://www.instagram.com", "◎", "#E1306C"),
            QuickSiteItem("X", "https://x.com", "𝕏", "#111111"),
            QuickSiteItem("GitHub", "https://github.com", "GH", "#6E40C9"),
            QuickSiteItem("Wikipedia", "https://www.wikipedia.org", "W", "#3366CC"),
            QuickSiteItem("DuckDuckGo", "https://duckduckgo.com", "D", "#DE5833")
        )
    }

    fun addQuickSite(title: String, url: String) {
        val cleanUrl = if (url.startsWith("http")) url else "https://$url"
        val glyph = title.trim().firstOrNull()?.uppercase() ?: "★"
        val list = defaultQuickSites()
        list.add(QuickSiteItem(title.trim().ifBlank { cleanUrl }, cleanUrl, glyph, "#E55A52"))
        val arr = JSONArray()
        list.forEach {
            arr.put(JSONObject().put("title", it.title).put("url", it.url).put("glyph", it.glyph).put("color", it.colorHex))
        }
        prefs.edit().putString("quick_sites_json", arr.toString()).apply()
    }

    fun saveCustomWallpaper(uri: Uri): Boolean {
        return try {
            val inp = context.contentResolver.openInputStream(uri) ?: return false
            val bmp = BitmapFactory.decodeStream(inp)
            inp.close()
            if (bmp == null) return false
            val scaled = Bitmap.createScaledBitmap(bmp, 480, 854, true)
            val out = File(context.filesDir, "pb_custom_bg.jpg")
            FileOutputStream(out).use { fos ->
                scaled.compress(Bitmap.CompressFormat.JPEG, 76, fos)
            }
            activeTheme = THEME_CUSTOM
            true
        } catch (e: Exception) {
            false
        }
    }

    fun getBackgroundDrawable(): Drawable? {
        if (activeTheme == THEME_CUSTOM) {
            val f = File(context.filesDir, "pb_custom_bg.jpg")
            if (f.exists()) {
                val bmp = BitmapFactory.decodeFile(f.absolutePath)
                if (bmp != null) return BitmapDrawable(context.resources, bmp)
            }
        }
        val res = when (activeTheme) {
            THEME_SUNSET -> R.drawable.pb_theme_royal_sunset
            THEME_MINT -> R.drawable.pb_theme_cosmic_mint
            THEME_OCEAN -> R.drawable.pb_theme_ocean_wave
            else -> R.drawable.pb_theme_rose_quartz
        }
        return ContextCompat.getDrawable(context, res)
    }

    private fun createThemeBitmap(): Bitmap {
        val w = 270
        val h = 480
        val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bmp)
        val colors = when (activeTheme) {
            THEME_SUNSET -> intArrayOf(Color.parseColor("#FF9E00"), Color.parseColor("#9D4EDD"), Color.parseColor("#1A0933"))
            THEME_MINT -> intArrayOf(Color.parseColor("#052E2B"), Color.parseColor("#0E5A54"), Color.parseColor("#061326"))
            THEME_OCEAN -> intArrayOf(Color.parseColor("#0077B6"), Color.parseColor("#023E8A"), Color.parseColor("#03045E"))
            else -> intArrayOf(Color.parseColor("#F8D8D6"), Color.parseColor("#E8BEB8"), Color.parseColor("#D7A8A4"))
        }
        val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            shader = LinearGradient(0f, 0f, 0f, h.toFloat(), colors, null, Shader.TileMode.CLAMP)
        }
        canvas.drawRect(0f, 0f, w.toFloat(), h.toFloat(), paint)
        return bmp
    }

    private fun webBackgroundDataUri(): String {
        return try {
            val bmp: Bitmap? = if (activeTheme == THEME_CUSTOM) {
                val f = File(context.filesDir, "pb_custom_bg.jpg")
                if (f.exists()) BitmapFactory.decodeFile(f.absolutePath) else createThemeBitmap()
            } else {
                createThemeBitmap()
            }
            if (bmp != null) {
                val baos = ByteArrayOutputStream()
                bmp.compress(Bitmap.CompressFormat.JPEG, 68, baos)
                "data:image/jpeg;base64," + Base64.encodeToString(baos.toByteArray(), Base64.NO_WRAP)
            } else ""
        } catch (e: Exception) {
            ""
        }
    }

    fun buildSearchUrl(input: String): String {
        val t = input.trim()
        if (t.startsWith("http://") || t.startsWith("https://")) return t
        if (t.contains(".") && !t.contains(" ")) return "https://$t"
        val q = Uri.encode(t)
        return when (searchEngine) {
            "DuckDuckGo" -> "https://duckduckgo.com/?q=$q"
            "Bing" -> "https://www.bing.com/search?q=$q"
            "Yahoo" -> "https://search.yahoo.com/search?p=$q"
            "Brave" -> "https://search.brave.com/search?q=$q"
            "Startpage" -> "https://www.startpage.com/sp/search?query=$q"
            "Ecosia" -> "https://www.ecosia.org/search?q=$q"
            "Yandex" -> "https://yandex.com/search/?text=$q"
            else -> "https://www.google.com/search?q=$q"
        }
    }

    private val adDomains = listOf(
        "doubleclick.net", "googlesyndication.com", "googleadservices.com",
        "adnxs.com", "adsrvr.org", "taboola.com", "outbrain.com",
        "cpro.baidu.com", "pos.baidu.com", "popads.net", "propellerads.com"
    )

    fun shouldBlockUrl(url: String): Boolean {
        if (!adBlockEnabled) return false
        val low = url.lowercase()
        return adDomains.any { low.contains(it) }
    }

    fun applyPageEnhancements(webView: WebView) {
        if (adBlockEnabled) {
            val adScript = "(function(){var s=['[id*=\"ad_\"]','[id*=\"ads\"]','[class*=\"ad-banner\"]','[class*=\"sponsored\"]','ins.adsbygoogle'];s.forEach(function(q){document.querySelectorAll(q).forEach(function(e){e.remove();});});})();"
            webView.evaluateJavascript(adScript, null)
        }

        if (webWallpaperEnabled) {
            val uri = webBackgroundDataUri()
            val bgRule = if (uri.isNotEmpty()) {
                "html,body{background-color:transparent !important;background-image:linear-gradient(rgba(15,10,24,0.38),rgba(15,10,24,0.48)),url('" + uri + "') !important;background-size:cover !important;background-position:center center !important;background-attachment:fixed !important;color:#FFFFFF !important;}div,section,article,header,nav,main,footer,ul,li,table,tr,td{background-color:rgba(20,14,34,0.52) !important;color:#F8F5FF !important;border-color:rgba(255,255,255,0.14) !important;}a{color:#72EFDD !important;}"
            } else ""
            if (bgRule.isNotEmpty()) {
                val js = "(function(){var o=document.getElementById('pb-a17-theme');if(o)o.remove();var st=document.createElement('style');st.id='pb-a17-theme';st.textContent=" + JSONObject.quote(bgRule) + ";document.head.appendChild(st);})();"
                webView.evaluateJavascript(js, null)
            }
        } else {
            webView.evaluateJavascript("(function(){var o=document.getElementById('pb-a17-theme');if(o)o.remove();})();", null)
        }
    }

    fun getBookmarks(): MutableList<BookmarkEntry> {
        val raw = prefs.getString("bookmarks_json", "[]") ?: "[]"
        val arr = JSONArray(raw)
        val list = mutableListOf<BookmarkEntry>()
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            list.add(BookmarkEntry(o.getString("title"), o.getString("url")))
        }
        return list
    }

    fun addBookmark(title: String, url: String) {
        val list = getBookmarks()
        if (list.none { it.url == url }) {
            list.add(0, BookmarkEntry(title.ifBlank { url }, url))
            val arr = JSONArray()
            list.forEach { arr.put(JSONObject().put("title", it.title).put("url", it.url)) }
            prefs.edit().putString("bookmarks_json", arr.toString()).apply()
        }
    }

    fun getHistory(): MutableList<HistoryEntry> {
        val raw = prefs.getString("history_json", "[]") ?: "[]"
        val arr = JSONArray(raw)
        val list = mutableListOf<HistoryEntry>()
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            list.add(HistoryEntry(o.getString("title"), o.getString("url"), o.optLong("ts", 0L)))
        }
        return list
    }

    fun addHistory(title: String, url: String) {
        if (url.startsWith("power://")) return
        val list = getHistory()
        list.add(0, HistoryEntry(title.ifBlank { url }, url))
        val arr = JSONArray()
        list.take(100).forEach { arr.put(JSONObject().put("title", it.title).put("url", it.url).put("ts", it.timeMs)) }
        prefs.edit().putString("history_json", arr.toString()).apply()
    }

    fun getDownloads(): MutableList<DownloadEntry> {
        val raw = prefs.getString("downloads_json", "[]") ?: "[]"
        val arr = JSONArray(raw)
        val list = mutableListOf<DownloadEntry>()
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            list.add(DownloadEntry(o.getString("fileName"), o.getString("url"), o.optLong("ts", 0L)))
        }
        return list
    }

    fun addDownload(fileName: String, url: String) {
        val list = getDownloads()
        list.add(0, DownloadEntry(fileName, url))
        val arr = JSONArray()
        list.take(60).forEach { arr.put(JSONObject().put("fileName", it.fileName).put("url", it.url).put("ts", it.timeMs)) }
        prefs.edit().putString("downloads_json", arr.toString()).apply()
    }

    fun clearHistory() {
        prefs.edit().remove("history_json").apply()
    }
}
