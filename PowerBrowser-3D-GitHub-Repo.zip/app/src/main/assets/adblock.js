if (typeof(__ad_ids__) == "undefined") {
    var __ad_ids__ = new Array()
    %s
    //__ad_ids__[0] = "ad-header-mobile-contener"
    var __ad_classes__ = new Array()
    %s
    //__ad_classes__[0] = ".pagination"
    var __ad_z_index__ = %d
    function __ad_remove__() {
        for (var i in __ad_ids__) {
            var __ad_item__ = document.getElementById(__ad_ids__[i]);
            if (__ad_item__) {
                __ad_item__.parentNode.removeChild(__ad_item__);
                console.log("ad block js found ad id");
                __kuto__.onAdBlocked()
            }
        }

        for (var i = 0; i < __ad_classes__.length; i++) {
            var __ad_items__ = document.querySelectorAll(__ad_classes__[i]);
            for (var j = 0; j < __ad_items__.length; j++) {
                var __ad_item__ = __ad_items__[j]
                if (__ad_item__) {
                    __ad_item__.parentNode.removeChild(__ad_item__);
                    console.log("ad block js found ad class");
                    __kuto__.onAdBlocked()
                }
            }
        }

        if (__ad_z_index__ > 0) {
            var __ad_body_nodes__ = document.body.childNodes
            for (var i = 0; i < __ad_body_nodes__.length; i++) {
                var node = __ad_body_nodes__[i];
                if (node instanceof HTMLElement) {
                    try {
                        var zIndex = parseInt(window.getComputedStyle(node, null).zIndex)
                        var zPos = window.getComputedStyle(node, null).position.toLowerCase()

                        if (zIndex > __ad_z_index__ &&
                            (zPos == "fixed" || zPos == "absolute") &&
                            node.offsetWidth > (document.body.offsetWidth - 50) &&
                            node.offsetHeight > 0 && node.offsetHeight < 300) {

                            node.parentNode.removeChild(node);
                            console.log("ad block js found ad zIndex");
                            __kuto__.onAdBlocked()
                        }
                    } catch(err) {}
                }
            }
        }

        //删除yandex广告
        var __yatags__ = document.getElementsByTagName("yatag")
        while(__yatags__.length > 0) {
           var node = __yatags__[0]
           if (node) {
               node.parentNode.removeChild(node);
               console.log("ad block js found yatag");
               __kuto__.onAdBlocked();
           }

           __yatags__ = document.getElementsByTagName("yatag")
        }
    }

    if (__ad_ids__.length > 0 || __ad_classes__.length > 0 || __ad_z_index__ > 0) {
        setInterval("__ad_remove__()", 1000)
    }
}