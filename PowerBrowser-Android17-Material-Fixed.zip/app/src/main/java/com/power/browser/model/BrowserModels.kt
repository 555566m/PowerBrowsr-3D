package com.power.browser.model

import android.webkit.WebView

data class QuickSiteItem(
    val title: String,
    val url: String,
    val glyph: String,
    val colorHex: String
)

data class BookmarkEntry(
    val title: String,
    val url: String
)

data class HistoryEntry(
    val title: String,
    val url: String,
    val timeMs: Long = System.currentTimeMillis()
)

data class DownloadEntry(
    val fileName: String,
    val url: String,
    val timeMs: Long = System.currentTimeMillis()
)

data class TabSession(
    val id: Long = System.nanoTime(),
    var title: String = "Home",
    var url: String = "power://home",
    var isHome: Boolean = true,
    val webView: WebView
)
