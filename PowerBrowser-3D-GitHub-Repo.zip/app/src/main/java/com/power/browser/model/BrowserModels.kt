package com.power.browser.model

import android.webkit.WebView

data class SpeedDialItem(
    val title: String,
    val url: String,
    val initial: String,
    val badgeColor: Int
)

data class BookmarkItem(
    val title: String,
    val url: String
)

data class HistoryItem(
    val title: String,
    val url: String,
    val timestamp: Long = System.currentTimeMillis()
)

data class BrowserTab(
    val id: Long = System.nanoTime(),
    var title: String = "Home",
    var url: String = "power://home",
    var isHome: Boolean = true,
    val webView: WebView
)
