# Power Browser (3D Edition)

Fast, Secure, and User-friendly Android Web Browser with 3D Animated Logo, Instant Theme Setup, Custom Gallery Wallpaper Backgrounds (both Home & Web Pages), Built-in AdBlock, Multi-Tab Management, Incognito Mode, Bookmarks, and History.

## Build APK from Phone via GitHub Actions
1. Upload/extract this ZIP into your GitHub repository.
2. Open the **Actions** tab -> select **Build Power Browser APK** -> click **Run workflow**.
3. Download **`PowerBrowser-3D-Edition-APK`** from the completed run's **Artifacts**.
