package com.power.browser.ui

import android.animation.ObjectAnimator
import android.annotation.SuppressLint
import android.app.DownloadManager
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.print.PrintAttributes
import android.print.PrintManager
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.animation.OvershootInterpolator
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.webkit.*
import android.widget.*
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.bottomsheet.BottomSheetDialog
import com.power.browser.R
import com.power.browser.databinding.*
import com.power.browser.model.QuickSiteItem
import com.power.browser.model.TabSession
import com.power.browser.util.BrowserManager
import java.io.ByteArrayInputStream

class MainActivity : AppCompatActivity() {

    private lateinit var binding: PbActivityMainBinding
    private lateinit var manager: BrowserManager

    private val sessions = mutableListOf<TabSession>()
    private var activeIndex = 0
    private var blockedAds = 0
    private var isIncognito = false
    private var isDesktop = false
    private var isFullScreenMode = false

    private lateinit var topTabsAdapter: RecyclerView.Adapter<TopTabVH>
    private lateinit var quickTilesAdapter: RecyclerView.Adapter<QuickTileVH>

    private val pickWallpaper =
        registerForActivityResult(ActivityResultContracts.GetContent()) { uri: Uri? ->
            if (uri != null && manager.saveCustomWallpaper(uri)) {
                applyThemeAndSettings()
                pulseView(binding.ivThemeWallpaper)
                Toast.makeText(this, "Custom wallpaper applied!", Toast.LENGTH_SHORT).show()
            }
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = PbActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        manager = BrowserManager(this)

        setupTopTabStrip()
        setupQuickTiles()
        createTab(openImmediately = true)
        applyThemeAndSettings()
        setupNavigationAndActions()
        setupBackHandler()

        intent?.dataString?.let { u ->
            if (u.startsWith("http")) navigateTo(u)
        }
    }

    private fun pulseView(v: View) {
        v.cameraDistance = 8000f * resources.displayMetrics.density
        v.scaleX = 0.9f
        v.scaleY = 0.9f
        v.animate()
            .scaleX(1f)
            .scaleY(1f)
            .setDuration(260)
            .setInterpolator(OvershootInterpolator(1.4f))
            .start()
    }

    private fun animateMaterialSheet(v: View) {
        v.cameraDistance = 8000f * resources.displayMetrics.density
        v.translationY = 90f
        v.scaleX = 0.94f
        v.scaleY = 0.94f
        v.alpha = 0f
        v.animate()
            .translationY(0f)
            .scaleX(1f)
            .scaleY(1f)
            .alpha(1f)
            .setDuration(300)
            .setInterpolator(OvershootInterpolator(1.2f))
            .start()
    }

    private fun animateMenuGrid(grid: GridLayout) {
        val dist = 8000f * resources.displayMetrics.density
        for (i in 0 until grid.childCount) {
            val child = grid.getChildAt(i)
            child.cameraDistance = dist
            child.scaleX = 0.82f
            child.scaleY = 0.82f
            child.alpha = 0f
            child.animate()
                .scaleX(1f)
                .scaleY(1f)
                .alpha(1f)
                .setStartDelay((i * 14L).coerceAtMost(260L))
                .setDuration(240)
                .setInterpolator(OvershootInterpolator(1.25f))
                .start()
        }
    }

    private fun setupTopTabStrip() {
        binding.rvTopTabs.layoutManager = LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false)
        topTabsAdapter = object : RecyclerView.Adapter<TopTabVH>() {
            override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): TopTabVH {
                val v = LayoutInflater.from(parent.context).inflate(R.layout.pb_item_top_tab, parent, false)
                return TopTabVH(v)
            }

            override fun getItemCount() = sessions.size

            override fun onBindViewHolder(holder: TopTabVH, position: Int) {
                val s = sessions[position]
                val selected = position == activeIndex
                holder.pill.setBackgroundResource(
                    if (selected) R.drawable.pb_tab_active_bg else R.drawable.pb_tab_inactive_bg
                )
                holder.tvTitle.text = if (s.isHome) "Home" else s.title
                holder.itemView.setOnClickListener {
                    selectTab(position)
                    pulseView(holder.pill)
                }
                holder.btnClose.setOnClickListener {
                    removeTabAt(position)
                }
            }
        }
        binding.rvTopTabs.adapter = topTabsAdapter
    }

    class TopTabVH(v: View) : RecyclerView.ViewHolder(v) {
        val pill: LinearLayout = v.findViewById(R.id.topTabPill)
        val tvTitle: TextView = v.findViewById(R.id.tvTopTabTitle)
        val btnClose: ImageButton = v.findViewById(R.id.btnCloseTopTab)
    }

    private fun setupQuickTiles() {
        val list = manager.defaultQuickSites()
        binding.rvQuickTiles.layoutManager = GridLayoutManager(this, 5)
        quickTilesAdapter = object : RecyclerView.Adapter<QuickTileVH>() {
            override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): QuickTileVH {
                val v = LayoutInflater.from(parent.context).inflate(R.layout.pb_item_quick_tile, parent, false)
                return QuickTileVH(v)
            }

            override fun getItemCount() = list.size

            override fun onBindViewHolder(holder: QuickTileVH, position: Int) {
                val item = list[position]
                holder.tvName.text = item.title
                holder.tvGlyph.text = item.glyph
                try {
                    holder.tvGlyph.setTextColor(Color.parseColor(item.colorHex))
                } catch (_: Exception) {
                    holder.tvGlyph.setTextColor(Color.parseColor("#E55A52"))
                }
                holder.itemView.setOnClickListener {
                    pulseView(holder.circle)
                    navigateTo(item.url)
                }
            }
        }
        binding.rvQuickTiles.adapter = quickTilesAdapter
    }

    class QuickTileVH(v: View) : RecyclerView.ViewHolder(v) {
        val circle: FrameLayout = v.findViewById(R.id.tileCircle)
        val tvGlyph: TextView = v.findViewById(R.id.tvTileGlyph)
        val tvName: TextView = v.findViewById(R.id.tvTileName)
    }

    @SuppressLint("SetJavaScriptEnabled")
    private fun buildWebView(): WebView {
        return WebView(this).apply {
            setBackgroundColor(Color.TRANSPARENT)
            settings.apply {
                javaScriptEnabled = true
                domStorageEnabled = !isIncognito
                databaseEnabled = !isIncognito
                loadsImagesAutomatically = !manager.blockImagesEnabled
                useWideViewPort = true
                loadWithOverviewMode = true
                builtInZoomControls = true
                displayZoomControls = false
                allowFileAccess = true
                setSupportZoom(true)
                mixedContentMode = WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE
                if (isDesktop) {
                    userAgentString =
                        "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36"
                }
            }

            webViewClient = object : WebViewClient() {
                override fun shouldInterceptRequest(view: WebView?, request: WebResourceRequest?): WebResourceResponse? {
                    val req = request?.url?.toString() ?: return null
                    if (manager.shouldBlockUrl(req)) {
                        runOnUiThread {
                            blockedAds++
                        }
                        return WebResourceResponse("text/plain", "UTF-8", ByteArrayInputStream(ByteArray(0)))
                    }
                    return super.shouldInterceptRequest(view, request)
                }

                override fun onPageFinished(view: WebView?, url: String?) {
                    super.onPageFinished(view, url)
                    binding.loadProgressBar.visibility = View.GONE
                    val safeUrl = url ?: return
                    val cur = sessions.getOrNull(activeIndex)
                    if (cur != null && cur.webView == view) {
                        cur.url = safeUrl
                        cur.title = view?.title?.ifBlank { safeUrl } ?: safeUrl
                        binding.etAddressBar.setText(safeUrl)
                        topTabsAdapter.notifyDataSetChanged()
                    }
                    if (!isIncognito) {
                        manager.addHistory(view?.title ?: safeUrl, safeUrl)
                    }
                    view?.let { manager.applyPageEnhancements(it) }
                }
            }

            webChromeClient = object : WebChromeClient() {
                override fun onProgressChanged(view: WebView?, newProgress: Int) {
                    if (newProgress in 1..99) {
                        binding.loadProgressBar.visibility = View.VISIBLE
                        binding.loadProgressBar.progress = newProgress
                    } else {
                        binding.loadProgressBar.visibility = View.GONE
                    }
                }
            }

            setDownloadListener { url, userAgent, contentDisposition, mimeType, _ ->
                enqueueDownload(url, userAgent, contentDisposition, mimeType)
            }
        }
    }

    private fun enqueueDownload(url: String, userAgent: String, contentDisposition: String, mimeType: String) {
        try {
            val fileName = URLUtil.guessFileName(url, contentDisposition, mimeType)
            val req = DownloadManager.Request(Uri.parse(url)).apply {
                if (!mimeType.isNullOrBlank()) setMimeType(mimeType)
                if (!userAgent.isNullOrBlank()) addRequestHeader("User-Agent", userAgent)
                setTitle(fileName)
                setDescription("Power Downloader 17")
                setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
                setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, fileName)
            }
            val dm = getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager
            dm.enqueue(req)
            manager.addDownload(fileName, url)
            Toast.makeText(this, "Downloading: $fileName", Toast.LENGTH_SHORT).show()
        } catch (e: Exception) {
            Toast.makeText(this, "Download error: ${e.message}", Toast.LENGTH_SHORT).show()
        }
    }

    private fun createTab(openImmediately: Boolean) {
        val tab = TabSession(webView = buildWebView())
        sessions.add(tab)
        if (openImmediately) {
            selectTab(sessions.lastIndex)
        } else {
            refreshTabCounterLabel()
            topTabsAdapter.notifyDataSetChanged()
        }
    }

    private fun removeTabAt(index: Int) {
        if (index !in sessions.indices) return
        if (sessions.size > 1) {
            sessions[index].webView.destroy()
            sessions.removeAt(index)
            val target = activeIndex.coerceIn(0, sessions.lastIndex)
            selectTab(target)
        } else {
            sessions[0].isHome = true
            sessions[0].title = "Home"
            sessions[0].url = "power://home"
            selectTab(0)
        }
    }

    private fun selectTab(index: Int) {
        if (index !in sessions.indices) return
        activeIndex = index
        val s = sessions[index]
        binding.webViewHost.removeAllViews()
        binding.webViewHost.addView(
            s.webView,
            FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
        )
        if (s.isHome) {
            binding.homeStartScroll.visibility = View.VISIBLE
            binding.webViewHost.visibility = View.GONE
            binding.etAddressBar.setText("")
        } else {
            binding.homeStartScroll.visibility = View.GONE
            binding.webViewHost.visibility = View.VISIBLE
            binding.etAddressBar.setText(s.url)
            manager.applyPageEnhancements(s.webView)
        }
        refreshTabCounterLabel()
        topTabsAdapter.notifyDataSetChanged()
    }

    private fun refreshTabCounterLabel() {
        val currentDisplay = (activeIndex + 1).coerceAtLeast(1)
        val totalDisplay = sessions.size.coerceAtLeast(1)
        binding.tvNavTabCounter.text = "$currentDisplay/$totalDisplay"
    }

    private fun navigateTo(rawInput: String) {
        val url = manager.buildSearchUrl(rawInput)
        val s = sessions.getOrNull(activeIndex) ?: return
        s.isHome = false
        s.url = url
        binding.homeStartScroll.visibility = View.GONE
        binding.webViewHost.visibility = View.VISIBLE
        binding.etAddressBar.setText(url)
        s.webView.loadUrl(url)
        topTabsAdapter.notifyDataSetChanged()
        hideKeyboard()
    }

    private fun applyThemeAndSettings() {
        binding.ivThemeWallpaper.setImageDrawable(manager.getBackgroundDrawable())
        binding.tvActiveEngineChip.text = manager.searchEngine.take(3).uppercase()
        binding.tvModeBanner.visibility = if (isIncognito) View.VISIBLE else View.GONE
        sessions.forEach { s ->
            s.webView.settings.loadsImagesAutomatically = !manager.blockImagesEnabled
            if (!s.isHome) manager.applyPageEnhancements(s.webView)
        }
    }

    private fun setupNavigationAndActions() {
        binding.btnTopAddTab.setOnClickListener {
            pulseView(binding.btnTopAddTab)
            createTab(openImmediately = true)
        }

        binding.btnBarBookmark.setOnClickListener {
            pulseView(binding.btnBarBookmark)
            val s = sessions.getOrNull(activeIndex)
            if (s != null && !s.isHome) {
                manager.addBookmark(s.title, s.url)
                Toast.makeText(this, "Added to Bookmarks", Toast.LENGTH_SHORT).show()
            } else {
                showBookmarksDialog()
            }
        }

        binding.etAddressBar.setOnEditorActionListener { _, actionId, _ ->
            if (actionId == EditorInfo.IME_ACTION_GO || actionId == EditorInfo.IME_ACTION_SEARCH) {
                val txt = binding.etAddressBar.text.toString()
                if (txt.isNotBlank()) navigateTo(txt)
                true
            } else false
        }

        binding.btnBarReaderOrTheme.setOnClickListener {
            pulseView(binding.btnBarReaderOrTheme)
            showThemesSheet()
        }

        binding.btnBarRefresh.setOnClickListener {
            ObjectAnimator.ofFloat(binding.btnBarRefresh, "rotation", 0f, 360f).apply {
                duration = 420
                start()
            }
            val s = sessions.getOrNull(activeIndex) ?: return@setOnClickListener
            if (!s.isHome) s.webView.reload() else applyThemeAndSettings()
        }

        binding.btnAddQuickTile.setOnClickListener {
            pulseView(binding.btnAddQuickTile)
            showAddShortcutDialog()
        }

        binding.btnNavBack.setOnClickListener {
            pulseView(binding.btnNavBack)
            handleBack()
        }

        binding.btnNavForward.setOnClickListener {
            pulseView(binding.btnNavForward)
            val s = sessions.getOrNull(activeIndex) ?: return@setOnClickListener
            if (!s.isHome && s.webView.canGoForward()) s.webView.goForward()
        }

        binding.btnNavHome.setOnClickListener {
            pulseView(binding.btnNavHome)
            val s = sessions.getOrNull(activeIndex) ?: return@setOnClickListener
            s.isHome = true
            s.title = "Home"
            selectTab(activeIndex)
        }

        binding.btnNavTheme.setOnClickListener {
            pulseView(binding.btnNavTheme)
            showThemesSheet()
        }

        binding.btnNavTabCounter.setOnClickListener {
            pulseView(binding.btnNavTabCounter)
            createTab(openImmediately = true)
        }

        binding.btnNavMenu.setOnClickListener {
            pulseView(binding.btnNavMenu)
            showFullControlMenu()
        }
    }

    private fun showAddShortcutDialog() {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(40, 24, 40, 8)
        }
        val etName = EditText(this).apply { hint = "Shortcut name (e.g. Gmail)" }
        val etUrl = EditText(this).apply { hint = "URL (e.g. https://mail.google.com)" }
        box.addView(etName)
        box.addView(etUrl)

        AlertDialog.Builder(this)
            .setTitle("Add Quick Shortcut")
            .setView(box)
            .setPositiveButton("Add") { _, _ ->
                if (etUrl.text.isNotBlank()) {
                    manager.addQuickSite(etName.text.toString(), etUrl.text.toString())
                    setupQuickTiles()
                }
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun showSearchEnginePicker() {
        val arr = manager.searchEngines.toTypedArray()
        AlertDialog.Builder(this)
            .setTitle("Search Engine (${manager.searchEngine})")
            .setItems(arr) { _, which ->
                manager.searchEngine = arr[which]
                applyThemeAndSettings()
                Toast.makeText(this, "Search Engine: ${manager.searchEngine}", Toast.LENGTH_SHORT).show()
            }
            .show()
    }

    private fun showThemesSheet() {
        val dialog = BottomSheetDialog(this)
        val sheet = PbSheetThemesBinding.inflate(layoutInflater)
        dialog.setContentView(sheet.root)
        animateMaterialSheet(sheet.root)

        sheet.ivThemeLogoAnim.cameraDistance = 8000f * resources.displayMetrics.density
        ObjectAnimator.ofFloat(sheet.ivThemeLogoAnim, "rotationY", -25f, 25f).apply {
            duration = 1600
            repeatCount = ObjectAnimator.INFINITE
            repeatMode = ObjectAnimator.REVERSE
            start()
        }

        sheet.switchInjectWebWallpaper.isChecked = manager.webWallpaperEnabled
        sheet.switchInjectWebWallpaper.setOnCheckedChangeListener { _, checked ->
            manager.webWallpaperEnabled = checked
            applyThemeAndSettings()
        }

        sheet.btnPickCustomWall.setOnClickListener {
            dialog.dismiss()
            pickWallpaper.launch("image/*")
        }

        sheet.themeCardRose.setOnClickListener {
            manager.activeTheme = BrowserManager.THEME_ROSE
            applyThemeAndSettings()
            pulseView(sheet.themeCardRose)
        }
        sheet.themeCardSunset.setOnClickListener {
            manager.activeTheme = BrowserManager.THEME_SUNSET
            applyThemeAndSettings()
            pulseView(sheet.themeCardSunset)
        }
        sheet.themeCardMint.setOnClickListener {
            manager.activeTheme = BrowserManager.THEME_MINT
            applyThemeAndSettings()
            pulseView(sheet.themeCardMint)
        }
        sheet.themeCardOcean.setOnClickListener {
            manager.activeTheme = BrowserManager.THEME_OCEAN
            applyThemeAndSettings()
            pulseView(sheet.themeCardOcean)
        }

        dialog.show()
    }

    private fun showBookmarksDialog() {
        val list = manager.getBookmarks()
        if (list.isEmpty()) {
            Toast.makeText(this, "No saved bookmarks yet", Toast.LENGTH_SHORT).show()
            return
        }
        val labels = list.map { "${it.title}
${it.url}" }.toTypedArray()
        AlertDialog.Builder(this)
            .setTitle("Bookmarks")
            .setItems(labels) { _, which -> navigateTo(list[which].url) }
            .show()
    }

    private fun showHistoryDialog() {
        val list = manager.getHistory()
        if (list.isEmpty()) {
            Toast.makeText(this, "History is empty", Toast.LENGTH_SHORT).show()
            return
        }
        val labels = list.map { "${it.title}
${it.url}" }.toTypedArray()
        AlertDialog.Builder(this)
            .setTitle("History")
            .setItems(labels) { _, which -> navigateTo(list[which].url) }
            .show()
    }

    private fun showDownloadsDialog() {
        val list = manager.getDownloads()
        val msg = if (list.isEmpty()) {
            "No files downloaded yet. Tap any downloadable file or media link on a page."
        } else {
            list.joinToString("

") { "• ${it.fileName}
  ${it.url}" }
        }
        AlertDialog.Builder(this)
            .setTitle("Power Downloader (${list.size})")
            .setMessage(msg)
            .setPositiveButton("System Downloads") { _, _ ->
                startActivity(Intent(DownloadManager.ACTION_VIEW_DOWNLOADS))
            }
            .setNegativeButton("Close", null)
            .show()
    }

    private fun showFullControlMenu() {
        val dialog = BottomSheetDialog(this)
        val sheet = PbSheetFullMenuBinding.inflate(layoutInflater)
        dialog.setContentView(sheet.root)
        animateMaterialSheet(sheet.root)
        animateMenuGrid(sheet.menuFeatureGrid)

        sheet.sheetTvAdCount.text = blockedAds.toString()
        sheet.sheetBtnEngine.text = "Engine: ${manager.searchEngine}"
        sheet.tvLabelAdBlocker.text = if (manager.adBlockEnabled) "AdBlock ON" else "AdBlock OFF"
        sheet.tvLabelBlockImages.text = if (manager.blockImagesEnabled) "Images OFF" else "Block images"
        sheet.tvLabelDesktop.text = if (isDesktop) "Desktop ON" else "Desktop"

        sheet.sheetBtnReload.setOnClickListener {
            dialog.dismiss()
            sessions.getOrNull(activeIndex)?.webView?.reload()
        }
        sheet.sheetBtnEngine.setOnClickListener {
            dialog.dismiss()
            showSearchEnginePicker()
        }
        sheet.sheetBtnNewTabTop.setOnClickListener {
            dialog.dismiss()
            createTab(openImmediately = true)
        }
        sheet.sheetBtnThemesTop.setOnClickListener {
            dialog.dismiss()
            showThemesSheet()
        }

        sheet.actHistory.setOnClickListener { dialog.dismiss(); showHistoryDialog() }
        sheet.actDownloads.setOnClickListener { dialog.dismiss(); showDownloadsDialog() }
        sheet.actNewTab.setOnClickListener { dialog.dismiss(); createTab(openImmediately = true) }

        sheet.actImageViewer.setOnClickListener {
            dialog.dismiss()
            showThemesSheet()
        }

        sheet.actSaveAllImages.setOnClickListener {
            dialog.dismiss()
            val wv = sessions.getOrNull(activeIndex)?.webView
            if (wv != null && !sessions[activeIndex].isHome) {
                wv.evaluateJavascript("(function(){var imgs=Array.from(document.querySelectorAll('img')).map(function(i){return i.src;}).filter(Boolean);return imgs[0]||'';})();") { firstImg ->
                    val clean = firstImg?.trim('"') ?: ""
                    if (clean.startsWith("http")) {
                        enqueueDownload(clean, "", "", "image/jpeg")
                    } else {
                        Toast.makeText(this, "No downloadable image found on page", Toast.LENGTH_SHORT).show()
                    }
                }
            }
        }

        sheet.actFullScreen.setOnClickListener {
            dialog.dismiss()
            isFullScreenMode = !isFullScreenMode
            binding.topTabStripBar.visibility = if (isFullScreenMode) View.GONE else View.VISIBLE
            binding.addressBarRow.visibility = if (isFullScreenMode) View.GONE else View.VISIBLE
            Toast.makeText(this, if (isFullScreenMode) "Full screen ON" else "Normal view", Toast.LENGTH_SHORT).show()
        }

        sheet.actDarkMode.setOnClickListener {
            dialog.dismiss()
            manager.darkModeEnabled = !manager.darkModeEnabled
            manager.webWallpaperEnabled = true
            applyThemeAndSettings()
            Toast.makeText(this, if (manager.darkModeEnabled) "Dark glass active" else "Light glass active", Toast.LENGTH_SHORT).show()
        }

        sheet.actTranslate.setOnClickListener {
            dialog.dismiss()
            val cur = sessions.getOrNull(activeIndex)
            if (cur != null && !cur.isHome) {
                val trUrl = "https://translate.google.com/translate?sl=auto&tl=hi&u=" + Uri.encode(cur.url)
                navigateTo(trUrl)
            }
        }

        sheet.actReadAloud.setOnClickListener {
            dialog.dismiss()
            sessions.getOrNull(activeIndex)?.webView?.evaluateJavascript(
                "(function(){alert(document.body.innerText.slice(0,600));})();",
                null
            )
        }

        sheet.actTextToSpeech.setOnClickListener {
            dialog.dismiss()
            Toast.makeText(this, "Reader mode ready on page", Toast.LENGTH_SHORT).show()
        }

        sheet.actAddBookmark.setOnClickListener {
            dialog.dismiss()
            val cur = sessions.getOrNull(activeIndex)
            if (cur != null && !cur.isHome) {
                manager.addBookmark(cur.title, cur.url)
                Toast.makeText(this, "Page bookmarked", Toast.LENGTH_SHORT).show()
            }
        }

        sheet.actShareUrl.setOnClickListener {
            dialog.dismiss()
            val cur = sessions.getOrNull(activeIndex)
            val link = if (cur != null && !cur.isHome) cur.url else "https://www.google.com"
            startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).apply {
                type = "text/plain"
                putExtra(Intent.EXTRA_TEXT, link)
            }, "Share URL"))
        }

        sheet.actFindInPage.setOnClickListener {
            dialog.dismiss()
            val et = EditText(this).apply { hint = "Search in page..." }
            AlertDialog.Builder(this)
                .setTitle("Find in Page")
                .setView(et)
                .setPositiveButton("Find") { _, _ ->
                    sessions.getOrNull(activeIndex)?.webView?.findAllAsync(et.text.toString())
                }
                .show()
        }

        sheet.actBookmarksList.setOnClickListener { dialog.dismiss(); showBookmarksDialog() }

        sheet.actPrintPdf.setOnClickListener {
            dialog.dismiss()
            val wv = sessions.getOrNull(activeIndex)?.webView
            if (wv != null && !sessions[activeIndex].isHome) {
                val pm = getSystemService(Context.PRINT_SERVICE) as PrintManager
                pm.print("PowerBrowser_Page", wv.createPrintDocumentAdapter("PowerBrowser_Page"), PrintAttributes.Builder().build())
            }
        }

        sheet.actDns.setOnClickListener {
            dialog.dismiss()
            Toast.makeText(this, "Encrypted HTTPS + Ad Shield Active", Toast.LENGTH_SHORT).show()
        }

        sheet.actAdBlocker.setOnClickListener {
            dialog.dismiss()
            manager.adBlockEnabled = !manager.adBlockEnabled
            Toast.makeText(this, "Ad blocker: ${manager.adBlockEnabled}", Toast.LENGTH_SHORT).show()
        }

        sheet.actThemesWall.setOnClickListener { dialog.dismiss(); showThemesSheet() }

        sheet.actBlockImages.setOnClickListener {
            dialog.dismiss()
            manager.blockImagesEnabled = !manager.blockImagesEnabled
            applyThemeAndSettings()
            Toast.makeText(this, "Block images: ${manager.blockImagesEnabled}", Toast.LENGTH_SHORT).show()
        }

        sheet.actDesktopMode.setOnClickListener {
            dialog.dismiss()
            isDesktop = !isDesktop
            val s = sessions.getOrNull(activeIndex)
            s?.webView?.settings?.userAgentString = if (isDesktop) {
                "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36"
            } else null
            s?.webView?.reload()
        }

        sheet.actZoomIn.setOnClickListener {
            dialog.dismiss()
            val wv = sessions.getOrNull(activeIndex)?.webView ?: return@setOnClickListener
            wv.settings.textZoom = (wv.settings.textZoom + 15).coerceAtMost(180)
            Toast.makeText(this, "Text zoom: ${wv.settings.textZoom}%", Toast.LENGTH_SHORT).show()
        }

        sheet.actCopyUrl.setOnClickListener {
            dialog.dismiss()
            val cur = sessions.getOrNull(activeIndex)
            if (cur != null && !cur.isHome) {
                val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                cm.setPrimaryClip(ClipData.newPlainText("url", cur.url))
                Toast.makeText(this, "Copied URL", Toast.LENGTH_SHORT).show()
            }
        }

        sheet.actPageSource.setOnClickListener {
            dialog.dismiss()
            sessions.getOrNull(activeIndex)?.webView?.evaluateJavascript(
                "(function(){alert(document.documentElement.outerHTML.slice(0,500));})();",
                null
            )
        }

        sheet.actMemo.setOnClickListener {
            dialog.dismiss()
            val et = EditText(this).apply { setText(manager.memoText) }
            AlertDialog.Builder(this)
                .setTitle("Quick Memo")
                .setView(et)
                .setPositiveButton("Save") { _, _ -> manager.memoText = et.text.toString() }
                .show()
        }

        sheet.actClearData.setOnClickListener {
            dialog.dismiss()
            manager.clearHistory()
            WebStorage.getInstance().deleteAllData()
            CookieManager.getInstance().removeAllCookies(null)
            Toast.makeText(this, "Cleared data", Toast.LENGTH_SHORT).show()
        }

        // Bottom strip inside menu sheet
        sheet.sheetModeIncognito.setOnClickListener {
            dialog.dismiss()
            isIncognito = !isIncognito
            applyThemeAndSettings()
            Toast.makeText(this, if (isIncognito) "Incognito ON" else "Incognito OFF", Toast.LENGTH_SHORT).show()
        }
        sheet.sheetModeTheme.setOnClickListener { dialog.dismiss(); showThemesSheet() }
        sheet.sheetModeReader.setOnClickListener {
            dialog.dismiss()
            manager.webWallpaperEnabled = !manager.webWallpaperEnabled
            applyThemeAndSettings()
        }
        sheet.sheetModeDesktop.setOnClickListener {
            dialog.dismiss()
            isDesktop = !isDesktop
            sessions.getOrNull(activeIndex)?.webView?.reload()
        }
        sheet.sheetModeSearch.setOnClickListener { dialog.dismiss(); showSearchEnginePicker() }

        dialog.show()
    }

    private fun handleBack() {
        val s = sessions.getOrNull(activeIndex) ?: return
        if (!s.isHome && s.webView.canGoBack()) {
            s.webView.goBack()
        } else if (!s.isHome) {
            s.isHome = true
            selectTab(activeIndex)
        } else {
            finish()
        }
    }

    private fun setupBackHandler() {
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() = handleBack()
        })
    }

    private fun hideKeyboard() {
        val imm = getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
        imm.hideSoftInputFromWindow(binding.etAddressBar.windowToken, 0)
    }
}
